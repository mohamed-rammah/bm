use IDP_$(myENV)_FRAMEWORK
go

if exists(select * from [L1Config].[WORK_UNIT] where WORK_UNIT_NAME='L3_BOTW_CDM_CONS_RED')
begin
   
	if exists (select * from [L1Config].[EMAIL_NOTIFICATION] where UNIT_ID=(select WORK_UNIT_ID from [L1Config].[WORK_UNIT] where WORK_UNIT_NAME='L3_BOTW_CDM_CONS_RED'))
	begin

		DELETE FROM [L1Config].[EMAIL_NOTIFICATION] where UNIT_ID=(select WORK_UNIT_ID from [L1Config].[WORK_UNIT] where WORK_UNIT_NAME='L3_BOTW_CDM_CONS_RED')

	end

   DELETE FROM [L1Config].[WORK_UNIT] WHERE WORK_UNIT_NAME = 'L3_BOTW_CDM_CONS_RED'
   
end
go

declare @unit_id int,@to_email nvarchar(1000),@tgt_DB nvarchar(1000), @depend_group_id int

if not exists(select * from [L1Config].[WORK_UNIT] where WORK_UNIT_NAME='L3_BOTW_CDM_CONS_RED')
begin

	if '$(myENV)'='PRD'
		select @to_email='HUBIDPSupport@bmo.com;CRDRRetailProductionSupport@bmo.com'
				, @tgt_DB='IDP_$(myENV)_LEVEL3'
	else 
		select @to_email='RetailMartsDEVTeam@bmo.com'
				, @tgt_DB='IDP_$(myENV)_LEVEL3'

	insert into [L1Config].[WORK_UNIT]( WORK_UNIT_NAME,WORK_GROUP_PACKAGE,WORK_UNIT_PACKAGE,ENABLED,TARGET_DATA_LEVEL,TARGET_DB,POWERDESIGNERCURRENTVERSION)
	values ('L3_BOTW_CDM_CONS_RED','L3_BOTW_CDM_CONS_RED_M_WorkGroup.dtsx',null,1,'LEVEL3',@tgt_DB,'R12_IDP_05')
	
	set @unit_id=@@identity
	print @unit_id
	if not exists (select * from [L1Config].[EMAIL_NOTIFICATION] where UNIT_ID=@unit_id)
	begin

		insert into [L1Config].[EMAIL_NOTIFICATION](UNIT_ID,NOTIFICATION_TYPE,NOTIFICATION_START_TIME,NOTIFICATION_END_TIME,TO_EMAILS,SUBJECT,MESSAGE)
		values(@unit_id,'Success',NULL,NULL,@to_email,'Work Unit: @WorkUnit Loaded Successfully','Work Unit Loaded successfully')

		insert into [L1Config].[EMAIL_NOTIFICATION](UNIT_ID,NOTIFICATION_TYPE,NOTIFICATION_START_TIME,NOTIFICATION_END_TIME,TO_EMAILS,SUBJECT,MESSAGE)
		values(@unit_id,'Failure',NULL,NULL,@to_email,'Work Unit: @WorkUnit Failed','Work Unit Failed. @ErrorMessage')

	end
	
end
